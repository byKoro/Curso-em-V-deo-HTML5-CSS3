import { world } from '@minecraft/server'
import { ActionFormData} from '@minecraft/server-ui'

const gui = new ActionFormData()
gui.title('§l§5[Warps]')
gui.body('   Aproveite para explorar todas as                          opções')
gui.button('§5§l[HUB]\n§r§3Volte ao HUB',"textures/MenuIcon/hub.png")
gui.button('§5§l[LOJA]\n§r§3Compre e venda itens',"textures/MenuIcon/shop.png")
gui.button('§5§l[MINA]\n§r§3Colete minérios',"textures/MenuIcon/mine.png")

world.events.beforeItemUse.subscribe(eventData => {
    const player = eventData.source;
    if(eventData.item.nameTag.includes("(Clique)")) {
        gui.show(player).then(result => {
            if(result.selection === 0){
                player.runCommandAsync("function tphub");
            }
            if(result.selection === 1){
                player.runCommandAsync("function tpshop") 
            }
            if(result.selection === 2){
                player.runCommandAsync("function tpmine") 
            }
        })
    }
})

